/*
 *  Copyright (c) 2005 Sun Microsystems, Inc.  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  2. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  3. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Sun Microsystems, Inc. for Project JXTA."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  4. The names "Sun", "Sun Microsystems, Inc.", "JXTA" and "Project JXTA"
 *  must not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact Project JXTA at http://www.jxta.org.
 *
 *  5. Products derived from this software may not be called "JXTA",
 *  nor may "JXTA" appear in their name, without prior written
 *  permission of Sun.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL SUN MICROSYSTEMS OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *
 *  ====================================================================
 *
 *  This software consists of voluntary contributions made by many
 *  individuals on behalf of Project JXTA.  For more
 *  information on Project JXTA, please see
 *  <http://www.jxta.org/>.
 *
 *  This license is based on the BSD license adopted by the Apache Foundation.
 */

package org.apache.log4j;
public class Level {
  private static final Level level = new Level();
  public static final int OFF_INT = Integer.MAX_VALUE;
  public static final int FATAL_INT = 50000;
  public static final int ERROR_INT = 40000;
  public static final int WARN_INT = 30000;
  public static final int INFO_INT = 20000;
  public static final int DEBUG_INT = 10000;
  public static final int TRACE_INT = 5000;
  public static final int ALL_INT = Integer.MIN_VALUE;
  public static final Level OFF = level;
  public static final Level FATAL = level;
  public static final Level ERROR = level;
  public static final Level WARN = level;
  public static final Level INFO = level;
  public static final Level DEBUG = level;
  public static final Level TRACE = level;
  public static final Level ALL = level;
  int lvl=0;
  String levelStr="stub";
  int syslogEquivalent=0;
  protected Level() {
  }
  public static Level toLevel(String sArg) {
    return level;
  }
  public static Level toLevel(int val) {
    return level;
  }
  public final int getSyslogEquivalent() {
    return syslogEquivalent;
  }
  public boolean isGreaterOrEqual(Level r) {
    return false;
  }
  public static Level[] getAllPossiblePriorities() {
    return new Level[] {
      Level.FATAL, Level.ERROR, Level.WARN, Level.INFO, Level.DEBUG,
      Level.TRACE
    };
  }
  public final String toString() {
    return levelStr;
  }
  public final int toInt() {
    return lvl;
  }
  public static Level toLevel(int val, Level defaultLevel) {
    switch (val) {
    case ALL_INT:
      return ALL;
    case TRACE_INT:
      return TRACE;
    case DEBUG_INT:
      return DEBUG;
    case INFO_INT:
      return INFO;
    case WARN_INT:
      return WARN;
    case ERROR_INT:
      return ERROR;
    case FATAL_INT:
      return FATAL;
    case OFF_INT:
      return OFF;
    default:
      return defaultLevel;
    }
  }
  public static Level toLevel(String sArg, Level defaultLevel) {
    if (sArg == null) {
      return defaultLevel;
    }
    String s = sArg.toUpperCase();
    if (s.equals("ALL")) {
      return ALL;
    }
    if (s.equals("TRACE")) {
      return TRACE;
    }
    if (s.equals("DEBUG")) {
      return DEBUG;
    }
    if (s.equals("INFO")) {
      return INFO;
    }
    if (s.equals("WARN")) {
      return WARN;
    }
    if (s.equals("ERROR")) {
      return ERROR;
    }
    if (s.equals("FATAL")) {
      return FATAL;
    }
    if (s.equals("OFF")) {
      return OFF;
    }
    return defaultLevel;
  }
}
